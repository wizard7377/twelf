#!/bin/sh
nohup sml @SMLload=netserver.heap.x86-linux &
